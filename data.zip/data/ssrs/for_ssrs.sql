use AdventureWorks2014

select * from person.countryregion

select CountryRegionCode, name
from Person.CountryRegion

select DATEPART(yyyy,soh.duedate) as [YEAR] ,
SubTotal,TotalDue,SalesLastYear,[st].[group],cr.name as CITY_NAME
from sales.salesorderheader as soh
inner join sales.SalesTerritory as st on soh.territoryid=st.TerritoryID
inner join Person.CountryRegion as cr on st.CountryRegionCode= cr.CountryRegionCode
where DATEPART(yyyy,soh.duedate) = 2011 and cr.name = 'Canada'

select * from sales.salesorderheader
select * from Sales.SalesOrderDetail

select * from sales.SalesTerritory

select * from Sales.salesorderdetail

select distinct [Group] from sales.SalesTerritory

select distinct year(duedate) as Year from sales.salesorderheader order by YEAR
select distinct year(duedate) as Year from 
sales.salesorderheader order by YEAR



select * from AdventureWorks2014.sales.SalesOrderHeader
select * from AdventureWorks2014.sales.SalesTerritory
CREATE TABLE [OLE DB Destination] (
    [ModifiedDate] datetime,
    [TerritoryID] int,
    [Name] nvarchar(50),
    [CountryRegionCode] nvarchar(3),
    [Group] nvarchar(50),
    [SalesYTD] money,
    [SalesLastYear] money,
    [CostYTD] money,
    [CostLastYear] money,
    [rowguid] uniqueidentifier,

    [ProductID] int,
    [StartDate] datetime,
    [EndDate] datetime,
    [StandardCost] money
)



select * from Production.ProductCostHistory
select * from Person.CountryRegion


select distinct [Group] from sales.SalesTerritory

select distinct [Name] from sales.SalesTerritory where [Group] = 'Europe'


select DATEPART(YYYY,soh.duedate) as [Calendar Year],
st.[Group] as [Sales Territory Group],
cr.name as [Sales Territory country],
cr.name as [Sales Territory region],
sum(soh.TotalDue) as [Sales Amount] from Sales.SalesOrderHeader as soh
inner join Sales.SalesTerritory as st on soh.TerritoryID=st.TerritoryID
inner join Sales.SalesOrderDetail as sod on soh.SalesOrderID=sod.SalesOrderID
inner join Production.ProductCostHistory as pch on sod.ProductID=pch.ProductID
inner join Person.CountryRegion as cr on st.CountryRegionCode=cr.CountryRegionCode
group by DATEPART(yyyy,soh.DueDate),st.[Group],cr.Name
order by [Calendar Year]


select DATEPART(yyyy,soh.duedate) as [YEAR] ,
SubTotal,TotalDue,SalesLastYear,[st].[group],cr.name as CITY_NAME
from sales.salesorderheader as soh
inner join sales.SalesTerritory as st on soh.territoryid=st.TerritoryID
inner join Person.CountryRegion as cr on st.CountryRegionCode= cr.CountryRegionCode


select distinct DATEPART(yyyy,duedate) as [YEAR]  from sales.salesorderheader


select * from IS_demo_1 where ProductID > 850 

select * from is_demo_1



 

truncate table IS_demo_1_1
truncate table IS_demo_1_2




select DATEPART(yyyy,soh.duedate) as [YEAR] ,SubTotal,TotalDue,SalesLastYear,[st].[group],cr.name as CITY_NAME

from sales.salesorderheader as soh
inner join sales.SalesTerritory as st on soh.territoryid=st.TerritoryID
inner join sales.salesorderdetail as sod on soh.salesorderid = sod.SalesOrderDetailID
inner join production.ProductCostHistory as pch on sod.ProductID= pch.ProductID
inner join Person.CountryRegion as cr on st.CountryRegionCode= cr.CountryRegionCode
where st.name in (@CITY_OF_COUNTRY) and [st].[group] in (@COUNTRY_GROUP) and DATEPART(yyyy,soh.duedate) in (@YEAR)


select * from sales.SalesTerritory
select * from Person.CountryRegion
select * from production.ProductCostHistory
select * from sales.salesorderdetail



select distinct DATEPART(yyyy,duedate) [Calender year] from  Sales.SalesOrderHeader

select * from sales.SalesTerritory

select cr.name [Sales Territory Country],st.[Group]
from person.CountryRegion as cr
inner join Sales.SalesTerritory as st
on cr.CountryRegionCode=st.CountryRegionCode
where st.[Group] in ('europe','pacific','North America')

select [Group] from sales.SalesTerritory

select name from sales.salesTerritory where group in 

select distinct cr.name [Sales Territory Country]
from person.CountryRegion as cr
inner join Sales.SalesTerritory as st
on cr.CountryRegionCode=st.CountryRegionCode
where st.[Group] in (@CONT_NAME)


select name from sales.salesTerritory  where [Group] = 'Europe'
















