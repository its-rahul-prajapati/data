/*Create table product
(
	p_id int,
	p_name varchar(20),
	p_Stock int
)

-- drop table product
-- drop table product_entry
-- primary key save table ma aapva mate ?
-- table edit karoi ne identity aapva mate ?


alter table product 
add p_id int PRIMARY KEY identity(1,1)


*/


Create table product
(
	p_id int primary key identity(1,1),
	p_name varchar(20),
	p_Stock int
) 

select * from product

create table product_entry
(
	pe_id int primary key identity(1,1),
	pe_p_name varchar(20),
	pe_p_entry int
)

select * from product_entry

select * from product

insert into product
valueS('APPLE',250)

insert into product
valueS('MANGO',350)

insert into product
valueS('BANANA',500)

insert into product
valueS('GRAPES',290)

insert into product
valueS('ORANGE',400)

update product
set p_Stock = 250
where p_name = 'apple'


select * from product
select * from product_entry


ALTER procedure sp_stocks 
@name varchar(20), @qty int, @temp varchar(10) = 'less'
as
begin
    -- select @temp = p.p_stock from product p where p.p_name = @name
	
	if @temp ='add'
	begin 
		update product set p_stock = p_stock + @qty	where p_name = @name ;		
		insert into product_entry(pe_p_name, pe_p_entry) values (@name,(@qty - (2*@qty)))
	end
	else
	begin
		if (@qty > (select p.p_stock from product p where p.p_name = @name ))
		begin
			print('out of stock')
			-- print ('we have only '+@temp +' '+ @name)
		end
		else
		begin
			update product set p_stock = p_stock - @qty	where p_name = @name ;		
			insert into product_entry(pe_p_name, pe_p_entry) values (@name, @qty)
		end
	end
	select * from product
	select * from product_entry
end

exec sp_stocks 'apple', 10

exec sp_stocks 'apple', 300

exec sp_stocks 'apple', 100


select * from product
select * from product_entry



