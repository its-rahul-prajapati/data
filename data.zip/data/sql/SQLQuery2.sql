Select * Into duplic_tb From temp_2 Where 1 = 2
select * from duplic_tb


create table product(
product_id int,
product_name varchar(20),
product_stock int
)

create table selling(
s_id int primary key identity(1,1),
s_name varchar(20),
s_stock int
)

drop table selling
alter table selling 
add s_id int primary key 

-- ALTER TABLE selling alter column s_id  INT NOT NULL PRIMARY KEY IDENTITY(1,1)

insert into product values(1,'Apple',10)
insert into product values(2,'Orange',50)
insert into product values(3,'Grapes',100)

select max(salary) from temp_2 group by temp_2.gend





select * from temp_2 where salary=( select max(salary) from temp_2 group by gend )


alter procedure sp_highsalary
@gender varchar(10) = null
as
begin 
select top 1 * from temp_2
where gend = @gender or @gender is null
order by salary desc
end

exec sp_highsalary 'male'



select top 1 * from temp_2
where gend = 'female'
order by salary desc



alter procedure fruits 
@fruit_name varchar(20),
@quentity int
as
begin
update product set product_stock=product_stock-@quentity where product_name=@fruit_name
insert into selling (s_name,s_stock) values (@fruit_name,@quentity) 
select * from product
select * from selling
end

exec fruits 'apple' ,7

select * from product
update product set product_stock = 10   where product_name = 'apple'


select product_stock from product where product.product_stock>@quentity 



alter procedure fruits 
@fruit_name varchar(20),
@quentity int 
as
begin
declare @a int  = (select product_stock from product where product_name=@fruit_name)
if ((select product_stock from product  where product_name= @fruit_name) > @quentity ) 
begin 
	update product 
	set product_stock=product_stock-@quentity where product_name=@fruit_name
	insert into selling (s_name,s_stock) values (@fruit_name,@quentity) 
	select * from product
	select * from selling
end
else 
begin select 'Please enter Lower Quentity less then or equal  ' + cast(@a as varchar(20))
end
end
exec fruits 'orange' ,50

if ((select product_stock from product  where product_name= 'apple') != 0  ) 
begin select 'invalid' end
