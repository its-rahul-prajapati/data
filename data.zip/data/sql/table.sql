declare @a int = 1, @b int = 1
while @b<=10
begin 
	print concat(@a,'*', @b, '=', @a*@b)
	if @b = 10
	begin
		set @b=0
		set @a+=1
	end
		break 
set @b+=1
end





