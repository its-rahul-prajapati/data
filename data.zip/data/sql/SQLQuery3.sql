select * from temp_2
insert  into temp_2 values (5,'dhanush',25100,'male')
select * from temp_2 order by salary desc 

--**********************	display the data of employee with the same salary.    ********************************

select e.*
from temp_2 e
join temp_2 c
on e.salary=c.salary and e.u_name!=c.u_name order by e.salary desc




--*******************************************************************************************************

select id,u_name,salary,gend from (select *,dense_rank()over(order by salary desc)as rank_of_salary from temp_2 ) temp_2 where rank_of_salary=5

insert into temp_2 values (5,'Rahul',20100,'male')
Select Salary from temp_2 order by Salary DESC LIMIT 4,1
SELECT * FROM temp_2 ORDER BY salary DESC 


alter table temp_2
add rank_of_salary int,dense_rank()over(order by salary desc)


WITH Salaries AS
(
    SELECT 
       Salary, ROW_NUMBER() OVER(ORDER BY Salary DESC) AS 'RowNum'
    FROM 
       temp_2
)
SELECT
  salary
FROM
  Salaries
WHERE
   RowNum <= 5
   select * from temp_2




---the employees who earn more than the average salary in department id 2.

   create table employee (
   id int primary key identity,
   name varchar (50),
   department varchar(20),
   d_id int 
   )
   alter table employee
   add salary int

   insert into employee values ('meet','Marketing',3,10000),('suresh','Purcheser',4,15000),('hirva','HR',1,20000),('jayraj','Marketing',3,25000),('kalpesh','Purcheser',4,40000),('dhanush','HR',1,12000)


   select * from employee
   where d_id = 2 and salary >(select avg(salary) from employee)




   --	retrieve the average summary of all departments whose average salary is greater than the average salary in department id 2.


  select * from  (select d_id, avg(salary) as AVG_SALARY from employee
  group by d_id)employee where AVG_SALARY >(select distinct(AVG_SALARY) from employee where id = 3)

  select salary from employee where salary>(select salary from employee where id = 1)