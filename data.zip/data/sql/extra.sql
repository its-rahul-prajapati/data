
Create table demo_table
(
id int,
name varchar(20)
)


select * from demo_table


insert into demo_table
values(1,'abc')

insert into demo_table
values(2,'def')

insert into demo_table
values(3,'ghi')

insert into demo_table
values(4,'jkl')

insert into demo_table
values(5,'mno')

insert into demo_table(name,id)
select 'pqr',6

select * from demo_table


create schema abc

create table rahul.prajapati.abc.tmp
(
id int,
name varchar(20),
gender varchar(10)
)



